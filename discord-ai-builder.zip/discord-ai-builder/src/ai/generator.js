import OpenAI from 'openai';
import { config } from '../config.js';

const openai = new OpenAI({ apiKey: config.openaiKey });

export async function generateServerStructure(promptTheme) {
  const systemPrompt = `Jesteś profesjonalnym architektem serwerów Discord.
Twoim zadaniem jest stworzenie kompletnej struktury serwera na podstawie podanej tematyki.
Odpowiedz WYŁĄCZNIE poprawnym obiektem JSON bez żadnych formatowań markdown, bloków kodu ani dodatkowego tekstu.

Struktura JSON musi dokładnie odpowiadać schematowi:
{
  "roles": [
    { "name": "Właściciel", "color": "#FF0000", "hoist": true },
    { "name": "Moderator", "color": "#00FF00", "hoist": true },
    { "name": "Gracz", "color": "#0080FF", "hoist": false }
  ],
  "categories": [
    {
      "name": "💬 GŁÓWNE",
      "isAdminOnly": false,
      "channels": [
        { "name": "chat-ogólny", "type": "GUILD_TEXT", "topic": "Rozmowy na każdy temat" },
        { "name": "Główny Głłosowy", "type": "GUILD_VOICE", "topic": "" }
      ]
    },
    {
      "name": "🛡️ STREFA ADMINA",
      "isAdminOnly": true,
      "channels": [
        { "name": "rozmowy-adminów", "type": "GUILD_TEXT", "topic": "Prywatne rozmowy administracji" }
      ]
    }
  ]
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Zbuduj bogatą i dopracowaną strukturę serwera o tematyce: ${promptTheme}` }
    ],
    temperature: 0.7,
  });

  const rawText = response.choices[0].message.content.trim();
  const cleanedText = rawText.replace(/^```json\s*/i, '').replace(/```$/i, '');
  return JSON.parse(cleanedText);
}
