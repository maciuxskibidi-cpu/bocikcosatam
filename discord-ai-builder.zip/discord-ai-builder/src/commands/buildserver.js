import { 
  SlashCommandBuilder, 
  PermissionFlagsBits, 
  ChannelType, 
  PermissionsBitField,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  EmbedBuilder
} from 'discord.js';
import { generateServerStructure } from '../ai/generator.js';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const buildServerCommand = {
  data: new SlashCommandBuilder()
    .setName('buildserver')
    .setDescription('Generuje i automatycznie buduje pełny serwer za pomocą AI')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(opt => 
      opt.setName('temat')
         .setDescription('Tematyka serwera (np. Gaming Minecraft, Społeczność Programistyczna, Szkoła)')
         .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const theme = interaction.options.getString('temat');
    const guild = interaction.guild;

    try {
      const initEmbed = new EmbedBuilder()
        .setTitle('🤖 AI Server Builder')
        .setDescription(`Analizuję temat **"${theme}"** i projektuję strukturę serwera...`)
        .setColor('#5865F2')
        .setTimestamp();

      await interaction.editReply({ embeds: [initEmbed] });

      const structure = await generateServerStructure(theme);

      // 1. Tworzenie ról z obsługą błędów i opóźnieniem
      const createdRoles = {};
      let adminRole = null;

      for (const roleData of structure.roles || []) {
        try {
          const role = await guild.roles.create({
            name: roleData.name,
            color: roleData.color || '#99aab5',
            hoist: roleData.hoist || false,
            reason: 'AI Server Builder'
          });
          createdRoles[roleData.name] = role;
          if (!adminRole && (roleData.name.toLowerCase().includes('admin') || roleData.name.toLowerCase().includes('właściciel'))) {
            adminRole = role;
          }
          await delay(300);
        } catch (e) {
          console.error(`Nie udało się utworzyć roli ${roleData.name}:`, e);
        }
      }

      // 2. Tworzenie kategorii i kanałów
      for (const catData of structure.categories || []) {
        try {
          const permissionOverwrites = [];
          
          if (catData.isAdminOnly && adminRole) {
            permissionOverwrites.push(
              {
                id: guild.roles.everyone.id,
                deny: [PermissionsBitField.Flags.ViewChannel]
              },
              {
                id: adminRole.id,
                allow: [PermissionsBitField.Flags.ViewChannel]
              }
            );
          }

          const category = await guild.channels.create({
            name: catData.name,
            type: ChannelType.GuildCategory,
            permissionOverwrites: permissionOverwrites.length > 0 ? permissionOverwrites : undefined,
            reason: 'AI Server Builder'
          });

          await delay(300);

          for (const chanData of catData.channels || []) {
            const type = chanData.type === 'GUILD_VOICE' ? ChannelType.GuildVoice : ChannelType.GuildText;
            await guild.channels.create({
              name: chanData.name,
              type: type,
              parent: category.id,
              topic: chanData.topic || '',
              reason: 'AI Server Builder'
            });
            await delay(300);
          }
        } catch (e) {
          console.error(`Nie udało się utworzyć kategorii ${catData.name}:`, e);
        }
      }

      // 3. Stworzenie strefy Ticketów
      const supportCategory = await guild.channels.create({
        name: '🛠️ WSPARCIE I POMOC',
        type: ChannelType.GuildCategory
      });

      const ticketChannel = await guild.channels.create({
        name: 'stworz-ticket',
        type: ChannelType.GuildText,
        parent: supportCategory.id,
        topic: 'Kliknij przycisk poniżej, aby otworzyć prywatny ticket wsparcia.'
      });

      const ticketBtn = new ButtonBuilder()
        .setCustomId('open_ticket')
        .setLabel('Otwórz Ticket')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📩');

      const ticketRow = new ActionRowBuilder().addComponents(ticketBtn);

      const ticketEmbed = new EmbedBuilder()
        .setTitle('🎫 Centrum Pomocy i Wsparcai')
        .setDescription('Potrzebujesz pomocy administracji? Kliknij przycisk poniżej, aby otworzyć prywatny kanał zgłoszenia.')
        .setColor('#57F287');

      await ticketChannel.send({ embeds: [ticketEmbed], components: [ticketRow] });

      // 4. Stworzenie kanału logów bota
      const logChannel = await guild.channels.create({
        name: 'logs-bot',
        type: ChannelType.GuildText,
        parent: supportCategory.id,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          }
        ]
      });

      const successEmbed = new EmbedBuilder()
        .setTitle('✅ Serwer Gotowy!')
        .setDescription(`Serwer o tematyce **"${theme}"** został pomyślnie utworzony!\n\n- Stworzono role i kategorie\n- Skonfigurowano strefę wsparcia i ticketów\n- Utworzono kanał logów ${logChannel}`)
        .setColor('#57F287')
        .setTimestamp();

      await interaction.followUp({ embeds: [successEmbed] });

    } catch (err) {
      console.error(err);
      await interaction.followUp('❌ Wystąpił błąd podczas generowania serwera. Sprawdź konsolę.');
    }
  }
};
