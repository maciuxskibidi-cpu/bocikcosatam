import { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } from 'discord.js';

const templates = {
  gaming: {
    name: '🎮 Gaming & E-Sport',
    roles: [
      { name: 'Właściciel', color: '#E74C3C' },
      { name: 'Moderator', color: '#2ECC71' },
      { name: 'Gracz', color: '#3498DB' }
    ],
    categories: [
      {
        name: '📢 INFORMACJE',
        channels: [
          { name: 'regulamin', type: ChannelType.GuildText },
          { name: 'ogłoszenia', type: ChannelType.GuildText }
        ]
      },
      {
        name: '💬 STREFA GRACZA',
        channels: [
          { name: 'chat-ogólny', type: ChannelType.GuildText },
          { name: 'szukam-ekipy', type: ChannelType.GuildText },
          { name: 'Lobby 1', type: ChannelType.GuildVoice },
          { name: 'Lobby 2', type: ChannelType.GuildVoice }
        ]
      }
    ]
  },
  community: {
    name: '🌐 Społeczność ogólna',
    roles: [
      { name: 'Admin', color: '#9B59B6' },
      { name: 'VIP', color: '#F1C40F' },
      { name: 'Członek', color: '#1ABC9C' }
    ],
    categories: [
      {
        name: '💬 ROZMOWY',
        channels: [
          { name: 'witamy', type: ChannelType.GuildText },
          { name: 'ogólny', type: ChannelType.GuildText },
          { name: 'memy', type: ChannelType.GuildText },
          { name: 'Pogaduchy', type: ChannelType.GuildVoice }
        ]
      }
    ]
  }
};

export const templateCommand = {
  data: new SlashCommandBuilder()
    .setName('template')
    .setDescription('Tworzy serwer z gotowego szablonu bez użycia OpenAI')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(opt =>
      opt.setName('typ')
         .setDescription('Wybierz szablon')
         .setRequired(true)
         .addChoices(
           { name: 'Gaming & E-Sport', value: 'gaming' },
           { name: 'Społeczność Ogólna', value: 'community' }
         )
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const choice = interaction.options.getString('typ');
    const tmpl = templates[choice];
    const guild = interaction.guild;

    for (const r of tmpl.roles) {
      await guild.roles.create({ name: r.name, color: r.color }).catch(() => {});
    }

    for (const c of tmpl.categories) {
      const cat = await guild.channels.create({ name: c.name, type: ChannelType.GuildCategory }).catch(() => {});
      if (cat) {
        for (const ch of c.channels) {
          await guild.channels.create({ name: ch.name, type: ch.type, parent: cat.id }).catch(() => {});
        }
      }
    }

    const embed = new EmbedBuilder()
      .setTitle('✅ Szablon Zastosowany')
      .setDescription(`Pomyślnie wdrożono szablon: **${tmpl.name}**`)
      .setColor('#57F287');

    await interaction.editReply({ embeds: [embed] });
  }
};
