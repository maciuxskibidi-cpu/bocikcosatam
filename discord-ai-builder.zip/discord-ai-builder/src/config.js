import dotenv from 'dotenv';
dotenv.config();

export const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  openaiKey: process.env.OPENAI_API_KEY,
};

if (!config.token || !config.openaiKey || !config.clientId) {
  console.error('❌ BŁĄD: Brak wymaganych zmiennych środowiskowych w pliku .env!');
  process.exit(1);
}
