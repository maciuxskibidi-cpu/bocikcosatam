import { EmbedBuilder } from 'discord.js';

export async function handleGuildMemberAdd(member) {
  // 1. Szukamy kanału powitalnego
  const welcomeChannel = member.guild.channels.cache.find(
    c => c.name.includes('powitania') || c.name.includes('witamy') || c.name.includes('welcome')
  );

  if (welcomeChannel) {
    const welcomeEmbed = new EmbedBuilder()
      .setTitle('👋 Nowy członek na serwerze!')
      .setDescription(`Witaj ${member}! Cieszymy się, że do nas dołączyłeś/aś na serwerze **${member.guild.name}**.`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setColor('#5865F2')
      .setTimestamp();

    welcomeChannel.send({ embeds: [welcomeEmbed] }).catch(() => {});
  }

  // 2. Automatyczne przydzielenie podstawowej roli
  const defaultRole = member.guild.roles.cache.find(
    r => r.name === 'Gracz' || r.name === 'Użytkownik' || r.name === 'Member' || r.name === 'Członek'
  );

  if (defaultRole) {
    try {
      await member.roles.add(defaultRole);
    } catch (e) {
      console.error('Brak uprawnień do nadania roli powitalnej.');
    }
  }
}
