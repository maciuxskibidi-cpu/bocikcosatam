import OpenAI from 'openai';
import { config } from '../config.js';

const openai = new OpenAI({ apiKey: config.openaiKey });

export async function handleMessageModeration(message) {
  if (message.author.bot || !message.guild) return;

  try {
    const moderation = await openai.moderations.create({ input: message.content });
    const result = moderation.results[0];

    if (result.flagged) {
      await message.delete().catch(() => {});
      
      const warning = await message.channel.send(
        `⚠️ ${message.author}, Twoja wiadomość została usunięta ze względu na naruszenie zasad społeczności.`
      );

      // Logowanie do kanału logs-bot
      const logChannel = message.guild.channels.cache.find(c => c.name === 'logs-bot');
      if (logChannel) {
        logChannel.send(
          `🛡️ **Auto-Moderacja AI**: Usunięto treść użytkownika ${message.author.tag} (${message.author.id}).\nTreść: \`"${message.content}"\``
        );
      }

      setTimeout(() => warning.delete().catch(() => {}), 6000);
    }
  } catch (err) {
    console.error('Błąd moderacji AI:', err);
  }
}
