import { ChannelType, PermissionFlagsBits, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } from 'discord.js';

export async function handleTicketInteraction(interaction) {
  if (!interaction.isButton()) return;

  const { guild, user, customId } = interaction;

  // 1. Otwieranie Ticketu
  if (customId === 'open_ticket') {
    const channelName = `ticket-${user.username}`.toLowerCase().replace(/[^a-z0-9]/g, '');

    const existingChannel = guild.channels.cache.find(c => c.name === channelName);
    if (existingChannel) {
      return interaction.reply({ content: `Masz już otwarty ticket: ${existingChannel}`, ephemeral: true });
    }

    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ],
        },
      ],
    });

    const closeBtn = new ButtonBuilder()
      .setCustomId('close_ticket')
      .setLabel('Zamknij Ticket')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒');

    const row = new ActionRowBuilder().addComponents(closeBtn);

    const embed = new EmbedBuilder()
      .setTitle(`🎫 Ticket użytkownika ${user.username}`)
      .setDescription('Witaj! Opisz szczegółowo swój problem. Zespół administracji wkrótce się z Tobą skontaktuje.')
      .setColor('#5865F2')
      .setTimestamp();

    await channel.send({ content: `${user}`, embeds: [embed], components: [row] });
    await interaction.reply({ content: `Utworzono Twój prywatny kanał wsparcia: ${channel}`, ephemeral: true });
  }

  // 2. Zamykanie Ticketu
  if (customId === 'close_ticket') {
    await interaction.reply({ content: '🔒 Kanał zostanie zamknięty i usunięty za 5 sekund...' });
    setTimeout(async () => {
      await interaction.channel.delete().catch(() => {});
    }, 5000);
  }
}
