import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import { config } from './config.js';
import { buildServerCommand } from './commands/buildserver.js';
import { templateCommand } from './commands/template.js';
import { handleGuildMemberAdd } from './events/guildMemberAdd.js';
import { handleMessageModeration } from './events/messageCreate.js';
import { handleTicketInteraction } from './handlers/ticketHandler.js';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

// Rejestracja komend Slash
const commands = [
  buildServerCommand.data.toJSON(),
  templateCommand.data.toJSON()
];

const rest = new REST({ version: '10' }).setToken(config.token);

client.once('ready', async () => {
  console.log(`=========================================`);
  console.log(`🤖 Bot Discord AI uruchomiony pomyślnie!`);
  console.log(`Zalogowano jako: ${client.user.tag}`);
  console.log(`=========================================`);

  try {
    await rest.put(
      Routes.applicationCommands(config.clientId),
      { body: commands }
    );
    console.log('✅ Komendy Slash zostały zarejestrowane globalnie.');
  } catch (error) {
    console.error('❌ Błąd rejestracji komend Slash:', error);
  }
});

// Interakcje (Komendy & Przyciski)
client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'buildserver') {
        await buildServerCommand.execute(interaction);
      } else if (interaction.commandName === 'template') {
        await templateCommand.execute(interaction);
      }
    } else if (interaction.isButton()) {
      await handleTicketInteraction(interaction);
    }
  } catch (err) {
    console.error('Błąd podczas obsługi interakcji:', err);
  }
});

// Eventy
client.on('guildMemberAdd', handleGuildMemberAdd);
client.on('messageCreate', handleMessageModeration);

client.login(config.token);
